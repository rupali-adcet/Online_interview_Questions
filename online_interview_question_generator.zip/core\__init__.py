"""
CogniHire Core Package
"""
